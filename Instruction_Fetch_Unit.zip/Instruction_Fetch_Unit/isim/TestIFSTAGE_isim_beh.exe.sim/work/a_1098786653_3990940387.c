/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/HPY_302/Instruction_Fetch_Unit/Sign_Extender.vhd";
extern char *IEEE_P_2592010699;



static void work_a_1098786653_3990940387_p_0(char *t0)
{
    char t20[16];
    char t22[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned int t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t21;
    char *t23;
    char *t24;
    int t25;
    unsigned int t26;
    unsigned char t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;

LAB0:    xsi_set_current_line(41, ng0);

LAB3:    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = (15 - 15);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    if (-1 == 1)
        goto LAB5;

LAB6:    t10 = 0;

LAB7:    t11 = (t10 - 0);
    t12 = (t11 * 1);
    t13 = (1U * t12);
    t14 = (t2 + t13);
    t15 = (0 - 15);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t17 = (1U * t16);
    memset(t14, t9, t17);
    t18 = (t0 + 1032U);
    t19 = *((char **)t18);
    t21 = ((IEEE_P_2592010699) + 4000);
    t23 = (t22 + 0U);
    t24 = (t23 + 0U);
    *((int *)t24) = 0;
    t24 = (t23 + 4U);
    *((int *)t24) = 15;
    t24 = (t23 + 8U);
    *((int *)t24) = 1;
    t25 = (15 - 0);
    t26 = (t25 * 1);
    t26 = (t26 + 1);
    t24 = (t23 + 12U);
    *((unsigned int *)t24) = t26;
    t24 = (t0 + 4272U);
    t18 = xsi_base_array_concat(t18, t20, t21, (char)97, t1, t22, (char)97, t19, t24, (char)101);
    t26 = (16U + 16U);
    t27 = (32U != t26);
    if (t27 == 1)
        goto LAB8;

LAB9:    t28 = (t0 + 2744);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t32, t18, 32U);
    xsi_driver_first_trans_fast_port(t28);

LAB2:    t33 = (t0 + 2664);
    *((int *)t33) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    t10 = 15;
    goto LAB7;

LAB8:    xsi_size_not_matching(32U, t26, 0);
    goto LAB9;

}


extern void work_a_1098786653_3990940387_init()
{
	static char *pe[] = {(void *)work_a_1098786653_3990940387_p_0};
	xsi_register_didat("work_a_1098786653_3990940387", "isim/TestIFSTAGE_isim_beh.exe.sim/work/a_1098786653_3990940387.didat");
	xsi_register_executes(pe);
}
