/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ds123f15/Documents/Xilinx_Projects/ask1_1/ALU.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_16439767405979520975_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_16439989832805790689_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_207919886985903570_503743352(char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_3488546069778340532_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_3488768496604610246_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_374109322130769762_503743352(char *, unsigned char );
char *ieee_p_3620187407_sub_1496620905533649268_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_1496620905533721142_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_0832606739_3212880686_p_0(char *t0)
{
    char t32[16];
    char t35[16];
    char t40[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t33;
    char *t34;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned char t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned char t54;
    unsigned char t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned char t59;
    unsigned char t60;
    unsigned char t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned char t65;
    unsigned char t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned char t70;
    unsigned char t71;
    unsigned char t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned char t76;
    unsigned char t77;
    unsigned char t78;

LAB0:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6590);
    t4 = xsi_mem_cmp(t1, t2, 4U);
    if (t4 == 1)
        goto LAB3;

LAB14:    t5 = (t0 + 6594);
    t7 = xsi_mem_cmp(t5, t2, 4U);
    if (t7 == 1)
        goto LAB4;

LAB15:    t8 = (t0 + 6598);
    t10 = xsi_mem_cmp(t8, t2, 4U);
    if (t10 == 1)
        goto LAB5;

LAB16:    t11 = (t0 + 6602);
    t13 = xsi_mem_cmp(t11, t2, 4U);
    if (t13 == 1)
        goto LAB6;

LAB17:    t14 = (t0 + 6606);
    t16 = xsi_mem_cmp(t14, t2, 4U);
    if (t16 == 1)
        goto LAB7;

LAB18:    t17 = (t0 + 6610);
    t19 = xsi_mem_cmp(t17, t2, 4U);
    if (t19 == 1)
        goto LAB8;

LAB19:    t20 = (t0 + 6614);
    t22 = xsi_mem_cmp(t20, t2, 4U);
    if (t22 == 1)
        goto LAB9;

LAB20:    t23 = (t0 + 6618);
    t25 = xsi_mem_cmp(t23, t2, 4U);
    if (t25 == 1)
        goto LAB10;

LAB21:    t26 = (t0 + 6622);
    t28 = xsi_mem_cmp(t26, t2, 4U);
    if (t28 == 1)
        goto LAB11;

LAB22:    t29 = (t0 + 6626);
    t31 = xsi_mem_cmp(t29, t2, 4U);
    if (t31 == 1)
        goto LAB12;

LAB23:
LAB13:    xsi_set_current_line(85, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)2, 32U);
    t3 = (t0 + 3984);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(86, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(87, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 2608U);
    t2 = *((char **)t1);
    t1 = (t0 + 6432U);
    t3 = (t0 + 6630);
    t6 = (t32 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 32;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t4 = (32 - 0);
    t47 = (t4 * 1);
    t47 = (t47 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t47;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t32);
    if (t50 != 0)
        goto LAB41;

LAB43:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4176);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB42:    t1 = (t0 + 3904);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(33, ng0);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t36 = ((IEEE_P_2592010699) + 4000);
    t37 = (t0 + 6352U);
    t33 = xsi_base_array_concat(t33, t35, t36, (char)99, (unsigned char)2, (char)97, t34, t37, (char)101);
    t38 = (t0 + 1192U);
    t39 = *((char **)t38);
    t41 = ((IEEE_P_2592010699) + 4000);
    t42 = (t0 + 6368U);
    t38 = xsi_base_array_concat(t38, t40, t41, (char)99, (unsigned char)2, (char)97, t39, t42, (char)101);
    t43 = ieee_p_3620187407_sub_1496620905533649268_3965413181(IEEE_P_3620187407, t32, t33, t35, t38, t40);
    t44 = (t0 + 2608U);
    t45 = *((char **)t44);
    t44 = (t45 + 0);
    t46 = (t32 + 12U);
    t47 = *((unsigned int *)t46);
    t48 = (1U * t47);
    memcpy(t44, t43, t48);
    xsi_set_current_line(34, ng0);
    t1 = (t0 + 2608U);
    t2 = *((char **)t1);
    t47 = (32 - 31);
    t48 = (t47 * 1U);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t3 = (t0 + 3984);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(35, ng0);
    t1 = (t0 + 2608U);
    t2 = *((char **)t1);
    t4 = (32 - 32);
    t47 = (t4 * -1);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t50 = *((unsigned char *)t1);
    t3 = (t0 + 4048);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t50;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = (31 - 31);
    t47 = (t4 * -1);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t50 = *((unsigned char *)t1);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t7 = (31 - 31);
    t51 = (t7 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t3 = (t5 + t53);
    t54 = *((unsigned char *)t3);
    t55 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t50, t54);
    t6 = (t0 + 2608U);
    t8 = *((char **)t6);
    t10 = (31 - 32);
    t56 = (t10 * -1);
    t57 = (1U * t56);
    t58 = (0 + t57);
    t6 = (t8 + t58);
    t59 = *((unsigned char *)t6);
    t60 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t59);
    t61 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t55, t60);
    t9 = (t0 + 1032U);
    t11 = *((char **)t9);
    t13 = (31 - 31);
    t62 = (t13 * -1);
    t63 = (1U * t62);
    t64 = (0 + t63);
    t9 = (t11 + t64);
    t65 = *((unsigned char *)t9);
    t66 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t65);
    t12 = (t0 + 1192U);
    t14 = *((char **)t12);
    t16 = (31 - 31);
    t67 = (t16 * -1);
    t68 = (1U * t67);
    t69 = (0 + t68);
    t12 = (t14 + t69);
    t70 = *((unsigned char *)t12);
    t71 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t70);
    t72 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t66, t71);
    t15 = (t0 + 2608U);
    t17 = *((char **)t15);
    t19 = (31 - 32);
    t73 = (t19 * -1);
    t74 = (1U * t73);
    t75 = (0 + t74);
    t15 = (t17 + t75);
    t76 = *((unsigned char *)t15);
    t77 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t72, t76);
    t78 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t61, t77);
    t18 = (t0 + 4112);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = t78;
    xsi_driver_first_trans_fast_port(t18);
    goto LAB2;

LAB4:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_2592010699) + 4000);
    t5 = (t0 + 6352U);
    t1 = xsi_base_array_concat(t1, t35, t3, (char)99, (unsigned char)2, (char)97, t2, t5, (char)101);
    t6 = (t0 + 1192U);
    t8 = *((char **)t6);
    t9 = ((IEEE_P_2592010699) + 4000);
    t11 = (t0 + 6368U);
    t6 = xsi_base_array_concat(t6, t40, t9, (char)99, (unsigned char)2, (char)97, t8, t11, (char)101);
    t12 = ieee_p_3620187407_sub_1496620905533721142_3965413181(IEEE_P_3620187407, t32, t1, t35, t6, t40);
    t14 = (t0 + 2608U);
    t15 = *((char **)t14);
    t14 = (t15 + 0);
    t17 = (t32 + 12U);
    t47 = *((unsigned int *)t17);
    t48 = (1U * t47);
    memcpy(t14, t12, t48);
    xsi_set_current_line(40, ng0);
    t1 = (t0 + 2608U);
    t2 = *((char **)t1);
    t47 = (32 - 31);
    t48 = (t47 * 1U);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t3 = (t0 + 3984);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(41, ng0);
    t1 = (t0 + 2608U);
    t2 = *((char **)t1);
    t4 = (32 - 32);
    t47 = (t4 * -1);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t50 = *((unsigned char *)t1);
    t3 = (t0 + 4048);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t50;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = (31 - 31);
    t47 = (t4 * -1);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t50 = *((unsigned char *)t1);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t7 = (31 - 31);
    t51 = (t7 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t3 = (t5 + t53);
    t54 = *((unsigned char *)t3);
    t55 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t54);
    t59 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t50, t55);
    t6 = (t0 + 2608U);
    t8 = *((char **)t6);
    t10 = (31 - 32);
    t56 = (t10 * -1);
    t57 = (1U * t56);
    t58 = (0 + t57);
    t6 = (t8 + t58);
    t60 = *((unsigned char *)t6);
    t61 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t60);
    t65 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t59, t61);
    t9 = (t0 + 1032U);
    t11 = *((char **)t9);
    t13 = (31 - 31);
    t62 = (t13 * -1);
    t63 = (1U * t62);
    t64 = (0 + t63);
    t9 = (t11 + t64);
    t66 = *((unsigned char *)t9);
    t70 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t66);
    t12 = (t0 + 1192U);
    t14 = *((char **)t12);
    t16 = (31 - 31);
    t67 = (t16 * -1);
    t68 = (1U * t67);
    t69 = (0 + t68);
    t12 = (t14 + t69);
    t71 = *((unsigned char *)t12);
    t72 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t70, t71);
    t15 = (t0 + 2608U);
    t17 = *((char **)t15);
    t19 = (31 - 32);
    t73 = (t19 * -1);
    t74 = (1U * t73);
    t75 = (0 + t74);
    t15 = (t17 + t75);
    t76 = *((unsigned char *)t15);
    t77 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t72, t76);
    t78 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t65, t77);
    t18 = (t0 + 4112);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = t78;
    xsi_driver_first_trans_fast_port(t18);
    goto LAB2;

LAB5:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6352U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 6368U);
    t6 = ieee_p_2592010699_sub_16439989832805790689_503743352(IEEE_P_2592010699, t32, t2, t1, t5, t3);
    t8 = (t32 + 12U);
    t47 = *((unsigned int *)t8);
    t48 = (1U * t47);
    t50 = (32U != t48);
    if (t50 == 1)
        goto LAB25;

LAB26:    t9 = (t0 + 3984);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast_port(t9);
    xsi_set_current_line(46, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(47, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6352U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 6368U);
    t6 = ieee_p_2592010699_sub_16439767405979520975_503743352(IEEE_P_2592010699, t32, t2, t1, t5, t3);
    t8 = (t32 + 12U);
    t47 = *((unsigned int *)t8);
    t48 = (1U * t47);
    t50 = (32U != t48);
    if (t50 == 1)
        goto LAB27;

LAB28:    t9 = (t0 + 3984);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast_port(t9);
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB7:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6352U);
    t3 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t32, t2, t1);
    t5 = (t32 + 12U);
    t47 = *((unsigned int *)t5);
    t48 = (1U * t47);
    t50 = (32U != t48);
    if (t50 == 1)
        goto LAB29;

LAB30:    t6 = (t0 + 3984);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(56, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(57, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB8:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = (31 - 31);
    t47 = (t4 * -1);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t50 = *((unsigned char *)t1);
    t3 = (t0 + 1032U);
    t5 = *((char **)t3);
    t51 = (31 - 31);
    t52 = (t51 * 1U);
    t53 = (0 + t52);
    t3 = (t5 + t53);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t35 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 31;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 31);
    t56 = (t7 * -1);
    t56 = (t56 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t56;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)99, t50, (char)97, t3, t35, (char)101);
    t56 = (1U + 31U);
    t54 = (32U != t56);
    if (t54 == 1)
        goto LAB31;

LAB32:    t11 = (t0 + 3984);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_fast_port(t11);
    xsi_set_current_line(61, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(62, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB9:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t47 = (31 - 31);
    t48 = (t47 * 1U);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t35 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 31;
    t8 = (t6 + 4U);
    *((int *)t8) = 1;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (1 - 31);
    t51 = (t4 * -1);
    t51 = (t51 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t51;
    t3 = xsi_base_array_concat(t3, t32, t5, (char)99, (unsigned char)2, (char)97, t1, t35, (char)101);
    t51 = (1U + 31U);
    t50 = (32U != t51);
    if (t50 == 1)
        goto LAB33;

LAB34:    t8 = (t0 + 3984);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(66, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(67, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB10:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t47 = (31 - 30);
    t48 = (t47 * 1U);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t35 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 30;
    t8 = (t6 + 4U);
    *((int *)t8) = 0;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (0 - 30);
    t51 = (t4 * -1);
    t51 = (t51 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t51;
    t3 = xsi_base_array_concat(t3, t32, t5, (char)97, t1, t35, (char)99, (unsigned char)2, (char)101);
    t51 = (31U + 1U);
    t50 = (32U != t51);
    if (t50 == 1)
        goto LAB35;

LAB36:    t8 = (t0 + 3984);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(71, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB11:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t47 = (31 - 30);
    t48 = (t47 * 1U);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t3 = (t0 + 1032U);
    t5 = *((char **)t3);
    t4 = (31 - 31);
    t51 = (t4 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t3 = (t5 + t53);
    t50 = *((unsigned char *)t3);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t35 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 30;
    t11 = (t9 + 4U);
    *((int *)t11) = 0;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (0 - 30);
    t56 = (t7 * -1);
    t56 = (t56 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t56;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)97, t1, t35, (char)99, t50, (char)101);
    t56 = (31U + 1U);
    t54 = (32U != t56);
    if (t54 == 1)
        goto LAB37;

LAB38:    t11 = (t0 + 3984);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_fast_port(t11);
    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB12:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = (0 - 31);
    t47 = (t4 * -1);
    t48 = (1U * t47);
    t49 = (0 + t48);
    t1 = (t2 + t49);
    t50 = *((unsigned char *)t1);
    t3 = (t0 + 1032U);
    t5 = *((char **)t3);
    t51 = (31 - 31);
    t52 = (t51 * 1U);
    t53 = (0 + t52);
    t3 = (t5 + t53);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t35 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 31;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 31);
    t56 = (t7 * -1);
    t56 = (t56 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t56;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)99, t50, (char)97, t3, t35, (char)101);
    t56 = (1U + 31U);
    t54 = (32U != t56);
    if (t54 == 1)
        goto LAB39;

LAB40:    t11 = (t0 + 3984);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_fast_port(t11);
    xsi_set_current_line(81, ng0);
    t1 = (t0 + 4048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(82, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB24:;
LAB25:    xsi_size_not_matching(32U, t48, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(32U, t48, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(32U, t48, 0);
    goto LAB30;

LAB31:    xsi_size_not_matching(32U, t56, 0);
    goto LAB32;

LAB33:    xsi_size_not_matching(32U, t51, 0);
    goto LAB34;

LAB35:    xsi_size_not_matching(32U, t51, 0);
    goto LAB36;

LAB37:    xsi_size_not_matching(32U, t56, 0);
    goto LAB38;

LAB39:    xsi_size_not_matching(32U, t56, 0);
    goto LAB40;

LAB41:    xsi_set_current_line(91, ng0);
    t8 = (t0 + 4176);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t8);
    goto LAB42;

}


extern void work_a_0832606739_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0832606739_3212880686_p_0};
	xsi_register_didat("work_a_0832606739_3212880686", "isim/ALU_TB_isim_beh.exe.sim/work/a_0832606739_3212880686.didat");
	xsi_register_executes(pe);
}
